---
name: Tropical Editorial Sanctuary
colors:
  surface: '#fbf9f3'
  surface-dim: '#dcdad4'
  surface-bright: '#fbf9f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ed'
  surface-container: '#f0eee8'
  surface-container-high: '#eae8e2'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c18'
  on-surface-variant: '#414846'
  inverse-surface: '#30312d'
  inverse-on-surface: '#f3f1eb'
  outline: '#717976'
  outline-variant: '#c0c8c5'
  surface-tint: '#3f655e'
  primary: '#002520'
  on-primary: '#ffffff'
  primary-container: '#123b35'
  on-primary-container: '#7da59d'
  inverse-primary: '#a5cfc6'
  secondary: '#536347'
  on-secondary: '#ffffff'
  secondary-container: '#d3e6c2'
  on-secondary-container: '#57684b'
  tertiary: '#311a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#4f2d00'
  on-tertiary-container: '#d09048'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ebe2'
  primary-fixed-dim: '#a5cfc6'
  on-primary-fixed: '#00201c'
  on-primary-fixed-variant: '#264d47'
  secondary-fixed: '#d6e9c5'
  secondary-fixed-dim: '#baccaa'
  on-secondary-fixed: '#111f09'
  on-secondary-fixed-variant: '#3b4b31'
  tertiary-fixed: '#ffdcbc'
  tertiary-fixed-dim: '#feb86c'
  on-tertiary-fixed: '#2c1700'
  on-tertiary-fixed-variant: '#683d00'
  background: '#fbf9f3'
  on-background: '#1b1c18'
  surface-variant: '#e4e2dd'
  surface-card: '#FFFFFF'
  text-primary: '#202825'
  text-secondary: '#6F7974'
  border-default: '#E2E6E1'
  status-success: '#287D54'
  status-warning: '#B97722'
  status-error: '#B94343'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3.5rem
  margin-tablet: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies modern tropical hospitality and high-end travel journalism, taking direct cues from the landscapes of East Nusa Tenggara (NTT)—from the savannas of Komodo and Sumba to the volcanic coastlines of Flores and Alor. It bridges the tactility of a printed luxury travel publication with the effortless clarity of modern hospitality platforms.

The aesthetic direction rejects generic travel tropes, artificial gradients, and tech-centric glassmorphism in favor of organic structure, sun-warmed neutrals, deep botanical anchors, and generous editorial white space. 

### Visual Pillars
- **Curated Editorialism:** Asymmetrical image pairings, clean typographic hierarchies, and deliberate margins evoke physical art books and travel journals.
- **Botanical Grounding:** Deep oceanic and rainforest greens anchor structural navigation, contrasted against warm ivory backdrops and sunbaked sand highlights.
- **Quiet Modernity:** Balanced geometric typography paired with subtle borders creates effortless readability without distracting from photography.

## Colors

The palette relies on chromatic balance drawn directly from East Nusa Tenggara’s natural terroir. The system operates strictly as a warm light experience; dark mode is deliberately omitted to preserve the tactile feel of sunlit linen and editorial stationery.

### Palette Roles
- **Primary (`#123B35` - Deep Forest Green):** Provides structural mass. Used for primary navigation headers, major editorial display titles, heavy footers, and foundational brand elements.
- **Secondary (`#D5E8C4` - Soft Sage):** Acts as a tranquil meadow highlight. Applied to tonal badge backgrounds, subtle callout cards, and active tab containers.
- **Tertiary / Brand Accent (`#E9A65B` - Sunset Sand):** Directs the eye to high-intent actions, primary booking triggers, key pricing indicators, and curated trip highlights.
- **Neutral Canvas (`#F7F5EF` - Warm Ivory):** Replaces sterile cold whites as the default page background, lending a gentle organic warmth.
- **Card Surface (`#FFFFFF`):** High-clarity white for cards, sheets, inputs, and modular overlays.
- **Text & Structure (`#202825`, `#6F7974`, `#E2E6E1`):** Deep charcoal ensures high legibility without the harshness of pure black, supported by neutral muted green-gray secondary typography and single-pixel structural hairline borders.

## Typography

Typography relies on `Plus Jakarta Sans`, configured to yield a disciplined, contemporary editorial tone. Its geometric clarity balances legibility on interactive interfaces with the stately confidence required for destination journalism.

### Typography Rules
- **Editorial Casing:** All headings, buttons, and metadata use sentence case. Uppercase is strictly restricted to minute utility eyebrow tags (under 12px) with relaxed tracking.
- **Line Heights:** Body scales adhere to a generous `1.6`–`1.65` relative line-height ratio, preventing dense text blocks and honoring an open, breathable reading rhythm.
- **Emphasis:** Display titles leverage bold weights (`700`), while section navigation and UI titles utilize medium-to-semibold weights (`500`–`600`) to maintain a quiet, sophisticated presence.

## Layout & Spacing

Layout geometry emphasizes expansive, uncluttered surfaces framed by rhythmic spacing derived from an 8px base grid. 

### Grid & Page Architecture
- **Desktop (1024px+):** 12-column fluid grid, maximum content container of `1280px`, outer margins scaling between `40px` and `64px`, with column gutters set to `24px` (`1.5rem`).
- **Tablet (768px - 1023px):** 6-column fluid grid, `32px` (`2rem`) margins, and `16px` gutters.
- **Mobile (<767px):** 4-column layout with `16px`–`20px` side padding to maximize screen real estate.

### Spacing Philosophy
Content blocks must not crowd each other. Sectional padding scales up to `88px` on desktop viewport heights, encouraging leisure browsing akin to turning the pages of an oversized travel quarterly.

## Elevation & Depth

This design system avoids excessive drop shadows, heavy blurs, and saturated glowing effects. Instead, visual depth is achieved through structural layering and soft environmental contact.

### Surface Stratification
- **Ground Tier (Canvas):** `#F7F5EF` Warm Ivory page background provides natural foundation.
- **Content Tier (Cards & Sheets):** Pure white `#FFFFFF` layered over Warm Ivory provides inherent tactile lift with zero shadow requirement in static states.
- **Structural Separation:** A single hairline stroke (`1px solid #E2E6E1`) delineates resting components, providing crisp separation while maintaining a clean, printed aesthetic.

### Ambient Elevation Levels
When interactive lift or sticky floating is mandatory, use warm, low-opacity ambient shadows:
- **Resting / Cards:** `0 1px 3px rgba(18, 59, 53, 0.04), 0 1px 2px rgba(18, 59, 53, 0.02)`
- **Hover / Interactive Cards:** `0 12px 24px -6px rgba(18, 59, 53, 0.08), 0 4px 8px -2px rgba(18, 59, 53, 0.03)`
- **Overlays & Floating Bars (Modals, Sticky Search):** `0 20px 32px -8px rgba(18, 59, 53, 0.12), 0 1px 2px rgba(18, 59, 53, 0.04)`

## Shapes

The shape language reflects polished architecture and sculpted natural contours. Roundedness level `2` sets a core radius of `8px` (`0.5rem`), transitioning to `12px`–`16px` for primary containers and cards.

### Corner Radius Standards
- **Component Enclosures (Cards, Modals, Panels):** `16px` (`rounded-xl` token) softens editorial images without feeling toy-like.
- **Interactive Controls (Inputs, Standard Buttons):** `8px` to `10px` balance tactile comfort with structural rigor.
- **Badges & Chips:** `6px` to `8px`. Rounded pill shapes (`9999px`) are intentionally avoided, preserving architectural composure across all micro-surfaces.
- **Imagery:** Image containers match their parent card's radius precisely, with inner top borders conforming to a `16px` clip.

## Components

### Buttons
- **Primary:** Background `#E9A65B` (Sunset Sand), text `#202825`, height `48px`, horizontal padding `24px`, border-radius `8px`, weight `600`. Hover shifts subtly darker (`#DF994C`) with a gentle `0 4px 12px rgba(233, 166, 91, 0.25)` glow.
- **Secondary / Ghost:** Outlined with `1.5px solid #123B35`, text `#123B35`, transparent background. On hover, background fills with `#123B35` and text turns `#FFFFFF`.
- **Tertiary / Link:** Inline link with text `#123B35`, accompanied by a thin trailing directional arrow icon with a 4px transition on hover.

### Destination & Tour Package Cards
- **Architecture:** Pure white container with `16px` border-radius and `1px solid #E2E6E1` hairline outline.
- **Media:** 4:3 ratio for tour cards and 3:4 for editorial destination vertical tiles. Imagery features natural color grading with no dark gradient vignettes over photographs.
- **Content:** Title rendered in `headline-sm` (`#123B35`), subtitle metadata in `label-sm` (`#6F7974`). Price callout utilizes `headline-sm` with currency displayed in body size.

### Badges & Meta Chips
- **Style:** Compact rectangular tags with `6px` radius; not pills.
- **Variants:**
  - *Highlight / Curated:* Background `#D5E8C4` (Soft Sage) with text `#123B35`.
  - *Standard Metadata:* Background `#F7F5EF` with border `1px solid #E2E6E1` and text `#202825`.
  - *Status:* Utilizing system semantic tokens with 10% opacity tints and high-contrast foreground text.

### Form Inputs & Search Bar
- **Field Sizing:** Height `50px`, padding `0 16px`, background `#FFFFFF`, border `1px solid #E2E6E1`, radius `8px`.
- **Focus State:** Border transitions to `#123B35` with an outer ring of `2px solid rgba(18, 59, 53, 0.12)`.
- **Compact Floating Search Module:** Elevated composite bar housing destination selector, travel dates, and party size within a unified white pill/soft container bordered by `#E2E6E1` and anchored by an `#E9A65B` submit button.

### Itinerary & Accordion Modules
- **Separators:** Clean `1px solid #E2E6E1` horizontal rules.
- **Expander:** Unobtrusive chevron line icon rotating 180 degrees. Active step in itineraries highlighted with a solid `#123B35` anchor dot and `#D5E8C4` vertical connecting stem.